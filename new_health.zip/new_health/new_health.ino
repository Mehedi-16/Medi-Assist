#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include "MAX30100_PulseOximeter.h"

LiquidCrystal_I2C lcd(0x27, 20, 4);

// ---------------- TEMP ----------------
#define ONE_WIRE_BUS 2
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

// ---------------- MAX30100 ----------------
PulseOximeter pox;

// ---------------- VARIABLES ----------------
float liveBpm = 0;
float spo2 = 0;
float temp = 0;

bool fingerDetected = false;

// ---------------- TIMER ----------------
uint32_t lastTemp = 0;
uint32_t lastDisplay = 0;
uint32_t lastSerial = 0;

// ---------------- LCD ----------------
void printLine(int row, String text) {
  while (text.length() < 20) text += ' ';
  lcd.setCursor(0, row);
  lcd.print(text.substring(0, 20));
}

// ---------------- SETUP ----------------
void setup() {
  Serial.begin(9600);

  lcd.init();
  lcd.backlight();
  sensors.begin();

  if (!pox.begin()) {
    printLine(1, "MAX30100 FAIL");
    while (1);
  }

  // 🔥 stable LED current (important)
  pox.setIRLedCurrent(MAX30100_LED_CURR_24MA);

  lcd.clear();
  printLine(1, "MEDI-ASSIST ROBOT");

  Serial.println("SYSTEM READY");
}

// ---------------- LOOP ----------------
void loop() {
  pox.update();

  liveBpm = pox.getHeartRate();
  spo2 = pox.getSpO2();

  // -------- TEMP --------
  if (millis() - lastTemp > 2000) {
    sensors.requestTemperatures();
    float t = sensors.getTempCByIndex(0);
    if (t > -100 && t < 100) temp = t;
    lastTemp = millis();
  }

  // -------- FINGER DETECTION (FIXED LOGIC) --------
  // SpO2 + signal based detection (better than BPM)
  if (spo2 > 80 || liveBpm > 40) {
    fingerDetected = true;
  } else {
    fingerDetected = false;
  }

  // -------- LCD --------
  if (millis() - lastDisplay > 400) {
    lastDisplay = millis();

    if (!fingerDetected) {
      printLine(0, "MEDI-ASSIST ROBOT");
      printLine(1, " ");
      printLine(2, "Place Finger");
      printLine(3, "On Sensor...");
    } 
    else {
      printLine(0, "BPM:  " + String(liveBpm, 1));
      printLine(1, "SpO2: " + String(spo2, 1));
      printLine(2, "Temp: " + String(temp, 1));
      printLine(3, "Reading...");
    }
  }

  // -------- SERIAL OUTPUT --------
  if (millis() - lastSerial > 1000) {
    lastSerial = millis();

    if (fingerDetected && spo2 > 70) {
      Serial.print("BPM:");
      Serial.print(liveBpm, 1);
      Serial.print(",SpO2:");
      Serial.print(spo2, 1);
      Serial.print(",Temp:");
      Serial.println(temp, 1);
    } else {
      Serial.println("BPM:0,SpO2:0,Temp:" + String(temp, 1));
    }
  }
}