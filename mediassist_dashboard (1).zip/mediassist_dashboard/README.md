# MediAssist Web Dashboard — Setup Guide

## ফাইল স্ট্রাকচার

```
mediassist/
├── app.py                    ← Flask backend (এটা চালাও)
├── mediassist.py             ← তোমার existing main code
├── dashboard_patch.py        ← integration instructions
├── requirements_dashboard.txt
└── templates/
    └── dashboard.html        ← Dashboard UI
```

---

## Step 1 — Install

```bash
pip install flask pyserial requests
```

---

## Step 2 — Arduino port set করো (optional)

`app.py` এর উপরে:
```python
ARDUINO_FOLLOWING_PORT = '/dev/ttyUSB0'   # তোমার port দাও
ARDUINO_HEALTH_PORT    = '/dev/ttyUSB1'
```

Arduino না থাকলে test করতে:
```python
DEMO_MODE = True   # fake sensor data দেবে
```

---

## Step 3 — দুটো terminal খোলো

**Terminal 1 — Dashboard:**
```bash
cd mediassist
python app.py
```

**Terminal 2 — Main Robot:**
```bash
python mediassist.py
```

---

## Step 4 — Browser এ দেখো

Raspberry Pi তে: http://localhost:5000
অন্য device থেকে: http://<pi-ip>:5000

Pi এর IP জানতে:
```bash
hostname -I
```

---

## Step 5 — mediassist.py এ voice log যোগ করো (optional)

`mediassist.py` তে import section এ:
```python
import requests
DASHBOARD_URL = "http://localhost:5000"

def _post_voice(role, text):
    try:
        requests.post(f"{DASHBOARD_URL}/api/voice_push",
                      json={"role": role, "text": text}, timeout=0.5)
    except:
        pass
```

`speak()` function এ শেষে:
```python
_post_voice("medi", text)
```

`process_command()` এ command পাওয়ার পরে:
```python
_post_voice("patient", command)
```

---

## Dashboard Features

- Real-time BPM, SpO2, Temperature (২ সেকেন্ডে update)
- Color-coded status (Normal / Elevated / Danger)
- Live trend chart (শেষ ২০ reading)
- Arduino + Gemini connection status
- Activity log (auto-alert সহ)
- Voice conversation log
- Quick command buttons (Follow / Stop / Health / Emergency)
- Auto-alert banner (abnormal vital পেলে)

---

## Auto-boot (optional)

Pi start হলে dashboard auto-start করতে:
```bash
# /etc/rc.local এ যোগ করো:
cd /home/pi/mediassist && python app.py &
```
