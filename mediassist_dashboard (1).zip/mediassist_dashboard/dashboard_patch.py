"""
mediassist_dashboard_patch.py
─────────────────────────────
এই file টা mediassist.py এর সাথে যোগ করো।

STEP 1: mediassist.py তে import এর নিচে এটা যোগ করো:
─────────────────────────────────────────────────────
import requests
DASHBOARD_URL = "http://localhost:5000"

STEP 2: speak() function এর শেষে এই line যোগ করো:
────────────────────────────────────────────────────
_post_voice("medi", text)

STEP 3: process_command() এ command recognize করার পরে এই line যোগ করো:
─────────────────────────────────────────────────────────────────────────
_post_voice("patient", command)

STEP 4: নিচের দুটো function mediassist.py তে যোগ করো:
"""

import requests

DASHBOARD_URL = "http://localhost:5000"

def _post_voice(role, text):
    """Dashboard এ voice log পাঠায়।"""
    try:
        requests.post(f"{DASHBOARD_URL}/api/voice_push",
                      json={"role": role, "text": text}, timeout=0.5)
    except Exception:
        pass   # Dashboard না চললেও main program চলবে


# ─────────────────────────────────────────────
# app.py তে এই route যোগ করো (api_voice এর নিচে):
# ─────────────────────────────────────────────

"""
@app.route('/api/voice_push', methods=['POST'])
def api_voice_push():
    from flask import request as req
    data = req.get_json(silent=True) or {}
    role = data.get('role', 'medi')
    text = data.get('text', '')
    if text:
        add_voice(role, text)
    return jsonify({"ok": True})
"""
