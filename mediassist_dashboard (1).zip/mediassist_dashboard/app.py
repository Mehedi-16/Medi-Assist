"""
MediAssist Web Dashboard - Flask Backend
Raspberry Pi এ চলবে, Arduino থেকে real-time data নেবে
Run: python app.py
Dashboard: http://<pi-ip>:5000
"""

from flask import Flask, render_template, jsonify
import serial
import serial.tools.list_ports
import threading
import time
import random
from collections import deque
from datetime import datetime

app = Flask(__name__)

# ─────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────

ARDUINO_FOLLOWING_PORT = None   # None = auto-detect, or '/dev/ttyUSB0'
ARDUINO_HEALTH_PORT    = None   # None = auto-detect, or '/dev/ttyUSB1'
ARDUINO_BAUD           = 9600
DEMO_MODE              = False  # True = fake data (Arduino না থাকলে test করো)

BPM_HISTORY_SIZE  = 20
LOG_HISTORY_SIZE  = 50

# ─────────────────────────────────────────────
#  STATE
# ─────────────────────────────────────────────

arduino_following = None
arduino_health    = None

health_data = {
    "BPM"  : 0.0,
    "SpO2" : 0.0,
    "Temp" : 0.0,
    "valid": False,
    "last_updated": None
}

bpm_history  = deque(maxlen=BPM_HISTORY_SIZE)
spo2_history = deque(maxlen=BPM_HISTORY_SIZE)
temp_history = deque(maxlen=BPM_HISTORY_SIZE)
time_history = deque(maxlen=BPM_HISTORY_SIZE)

robot_state = {
    "following"       : False,
    "arduino1_online" : False,
    "arduino2_online" : False,
    "gemini_online"   : True,
}

activity_log = deque(maxlen=LOG_HISTORY_SIZE)

voice_log = deque(maxlen=10)

# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────

def add_log(level, message):
    activity_log.appendleft({
        "time"   : datetime.now().strftime("%H:%M:%S"),
        "level"  : level,   # info / warn / danger / success
        "message": message
    })

def add_voice(role, text):
    voice_log.append({"role": role, "text": text, "time": datetime.now().strftime("%H:%M:%S")})

def get_bpm_status(bpm):
    if bpm <= 0:   return "no-data", "No data"
    if bpm > 120:  return "danger",  "Very high"
    if bpm > 100:  return "warn",    "Elevated"
    if bpm < 50:   return "danger",  "Very low"
    return "ok", "Normal"

def get_spo2_status(spo2):
    if spo2 <= 0:  return "no-data", "No data"
    if spo2 < 90:  return "danger",  "Critical"
    if spo2 < 95:  return "warn",    "Low"
    return "ok", "Normal"

def get_temp_status(temp):
    if temp <= 0:    return "no-data", "No data"
    if temp > 38.5:  return "danger",  "High fever"
    if temp > 37.5:  return "warn",    "Mild fever"
    if temp < 35.0:  return "danger",  "Hypothermia"
    return "ok", "Normal"

def check_alerts():
    alerts = []
    if not health_data["valid"]:
        return alerts
    b, s, t = health_data["BPM"], health_data["SpO2"], health_data["Temp"]
    if b > 120: alerts.append(f"Heart rate very high: {b:.0f} BPM")
    elif b < 50 and b > 0: alerts.append(f"Heart rate very low: {b:.0f} BPM")
    if s < 90 and s > 0: alerts.append(f"SpO₂ critically low: {s:.0f}%")
    elif s < 95 and s > 0: alerts.append(f"SpO₂ slightly low: {s:.0f}%")
    if t > 38.5: alerts.append(f"Fever: {t:.1f}°C")
    elif t < 35.0 and t > 0: alerts.append(f"Temp too low: {t:.1f}°C")
    return alerts

# ─────────────────────────────────────────────
#  ARDUINO
# ─────────────────────────────────────────────

def find_arduino_ports():
    ports = list(serial.tools.list_ports.comports())
    found = []
    for p in ports:
        if any(x in (p.description or "") for x in ['Arduino','CH340','ttyUSB','ttyACM']) \
           or 'ttyUSB' in p.device or 'ttyACM' in p.device:
            found.append(p.device)
    return found

def connect_arduinos():
    global arduino_following, arduino_health
    ports = find_arduino_ports()
    add_log("info", f"Found ports: {ports or 'none'}")

    used = set()
    for port in (([ARDUINO_FOLLOWING_PORT] if ARDUINO_FOLLOWING_PORT else ports)):
        if port in used:
            continue
        try:
            arduino_following = serial.Serial(port, ARDUINO_BAUD, timeout=1)
            robot_state["arduino1_online"] = True
            used.add(port)
            add_log("success", f"Following Arduino → {port}")
            break
        except Exception as e:
            add_log("warn", f"Following Arduino failed on {port}: {e}")

    for port in (([ARDUINO_HEALTH_PORT] if ARDUINO_HEALTH_PORT else ports)):
        if port in used:
            continue
        try:
            arduino_health = serial.Serial(port, ARDUINO_BAUD, timeout=1)
            robot_state["arduino2_online"] = True
            used.add(port)
            add_log("success", f"Health Arduino → {port}")
            break
        except Exception as e:
            add_log("warn", f"Health Arduino failed on {port}: {e}")

    if not arduino_following:
        add_log("warn", "Following Arduino not connected")
    if not arduino_health:
        add_log("warn", "Health Arduino not connected")

def read_health_thread():
    global health_data
    while True:
        try:
            if DEMO_MODE:
                # Simulate realistic sensor data
                import math
                t = time.time()
                health_data["BPM"]   = round(75 + 10 * math.sin(t / 20) + random.uniform(-2, 2), 1)
                health_data["SpO2"]  = round(97 + random.uniform(-1, 1), 1)
                health_data["Temp"]  = round(36.8 + random.uniform(-0.3, 0.3), 1)
                health_data["valid"] = True
                health_data["last_updated"] = datetime.now().strftime("%H:%M:%S")
                time.sleep(2)
                continue

            if arduino_health and arduino_health.is_open:
                raw = arduino_health.readline().decode('utf-8', errors='ignore').strip()
                # Expected: BPM:75.2,SpO2:98.1,Temp:36.5
                if 'BPM:' in raw and 'SpO2:' in raw and 'Temp:' in raw:
                    parts = {}
                    for seg in raw.split(','):
                        if ':' in seg:
                            k, v = seg.split(':', 1)
                            try:
                                parts[k.strip()] = float(v.strip())
                            except:
                                pass
                    if {'BPM','SpO2','Temp'}.issubset(parts):
                        prev_bpm = health_data["BPM"]
                        health_data["BPM"]   = parts["BPM"]
                        health_data["SpO2"]  = parts["SpO2"]
                        health_data["Temp"]  = parts["Temp"]
                        health_data["valid"] = True
                        health_data["last_updated"] = datetime.now().strftime("%H:%M:%S")
                        # Log big changes
                        if abs(parts["BPM"] - prev_bpm) > 10:
                            add_log("warn", f"BPM changed: {prev_bpm:.0f} → {parts['BPM']:.0f}")
            else:
                time.sleep(1)
        except Exception:
            time.sleep(0.5)

def history_thread():
    """Record vitals history every 3 seconds."""
    while True:
        if health_data["valid"]:
            bpm_history.append(round(health_data["BPM"], 1))
            spo2_history.append(round(health_data["SpO2"], 1))
            temp_history.append(round(health_data["Temp"], 1))
            time_history.append(datetime.now().strftime("%H:%M:%S"))
        time.sleep(3)

def alert_monitor_thread():
    last_alert = 0
    COOLDOWN   = 30
    while True:
        try:
            alerts = check_alerts()
            if alerts and time.time() - last_alert > COOLDOWN:
                last_alert = time.time()
                for a in alerts:
                    add_log("danger", f"AUTO-ALERT: {a}")
            time.sleep(10)
        except Exception:
            time.sleep(5)

# ─────────────────────────────────────────────
#  ROBOT COMMANDS
# ─────────────────────────────────────────────

def send_robot_cmd(cmd):
    try:
        if arduino_following and arduino_following.is_open:
            arduino_following.write((cmd + '\n').encode())
            add_log("info", f"Sent to robot: {cmd}")
            return True
        else:
            add_log("warn", "Following Arduino not connected")
            return False
    except Exception as e:
        add_log("danger", f"Robot command error: {e}")
        return False

# ─────────────────────────────────────────────
#  FLASK ROUTES
# ─────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('dashboard.html')

@app.route('/api/health')
def api_health():
    b, s, t = health_data["BPM"], health_data["SpO2"], health_data["Temp"]
    b_st, b_lb = get_bpm_status(b)
    s_st, s_lb = get_spo2_status(s)
    t_st, t_lb = get_temp_status(t)
    return jsonify({
        "valid"       : health_data["valid"],
        "last_updated": health_data["last_updated"],
        "BPM"         : round(b, 1),
        "SpO2"        : round(s, 1),
        "Temp"        : round(t, 1),
        "BPM_status"  : b_st,
        "BPM_label"   : b_lb,
        "SpO2_status" : s_st,
        "SpO2_label"  : s_lb,
        "Temp_status" : t_st,
        "Temp_label"  : t_lb,
        "alerts"      : check_alerts(),
    })

@app.route('/api/history')
def api_history():
    return jsonify({
        "times": list(time_history),
        "BPM"  : list(bpm_history),
        "SpO2" : list(spo2_history),
        "Temp" : list(temp_history),
    })

@app.route('/api/robot')
def api_robot():
    return jsonify({
        "following"       : robot_state["following"],
        "arduino1_online" : robot_state["arduino1_online"] or DEMO_MODE,
        "arduino2_online" : robot_state["arduino2_online"] or DEMO_MODE,
        "gemini_online"   : robot_state["gemini_online"],
    })

@app.route('/api/log')
def api_log():
    return jsonify(list(activity_log))

@app.route('/api/voice')
def api_voice():
    return jsonify(list(voice_log))

@app.route('/api/voice_push', methods=['POST'])
def api_voice_push():
    from flask import request as req
    data = req.get_json(silent=True) or {}
    role = data.get('role', 'medi')
    text = data.get('text', '')
    if text:
        add_voice(role, text)
    return jsonify({"ok": True})

@app.route('/api/command/<cmd>', methods=['POST'])
def api_command(cmd):
    if cmd == 'follow':
        ok = send_robot_cmd("FOLLOW")
        robot_state["following"] = ok or DEMO_MODE
        add_log("info", "Command: Follow me")
        add_voice("patient", "Follow me")
        add_voice("medi", "Starting to follow you now.")
        return jsonify({"ok": True})
    elif cmd == 'stop':
        ok = send_robot_cmd("STOP")
        robot_state["following"] = False
        add_log("info", "Command: Stop robot")
        add_voice("patient", "Stop")
        add_voice("medi", "I have stopped. Call me when you need me.")
        return jsonify({"ok": True})
    elif cmd == 'emergency':
        send_robot_cmd("STOP")
        robot_state["following"] = False
        add_log("danger", "EMERGENCY triggered!")
        add_voice("patient", "Emergency!")
        add_voice("medi", "Emergency alert! Calling for help. Please stay calm.")
        return jsonify({"ok": True})
    elif cmd == 'health':
        add_log("info", "Command: Health check")
        if health_data["valid"]:
            b, s, t = health_data["BPM"], health_data["SpO2"], health_data["Temp"]
            alerts = check_alerts()
            if alerts:
                msg = "Warning! " + ", ".join(alerts) + ". Please consult a doctor."
            else:
                msg = f"Heart rate {b:.0f} BPM, oxygen {s:.0f}%, temperature {t:.1f}°C. All normal."
        else:
            msg = "Health sensor not connected. Please place your finger on the sensor."
        add_voice("patient", "Check my health")
        add_voice("medi", msg)
        return jsonify({"ok": True, "message": msg})
    return jsonify({"ok": False, "error": "Unknown command"})

# ─────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────

if __name__ == '__main__':
    print("=" * 50)
    print("  MediAssist Dashboard Starting...")
    print(f"  Demo Mode: {DEMO_MODE}")
    print("=" * 50)

    add_log("info", "MediAssist Dashboard started")

    if not DEMO_MODE:
        connect_arduinos()

    # Background threads
    threading.Thread(target=read_health_thread,  daemon=True).start()
    threading.Thread(target=history_thread,       daemon=True).start()
    threading.Thread(target=alert_monitor_thread, daemon=True).start()

    add_log("success", "All systems ready")

    # Run Flask - accessible from any device on the network
    app.run(host='0.0.0.0', port=5000, debug=False)
